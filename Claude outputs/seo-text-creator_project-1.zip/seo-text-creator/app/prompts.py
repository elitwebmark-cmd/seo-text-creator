"""Промпти та схема відповіді для генерації ТЗ."""
import json
from pathlib import Path

EXAMPLE = json.loads((Path(__file__).parent / "examples" / "serm.json").read_text(encoding="utf-8"))

SYSTEM = """Ти — senior SEO-спеціаліст digital-агенції. Твоє завдання — за даними аналізу ТОПу Google (Україна) скласти професійне технічне завдання (ТЗ) копірайтеру на SEO-текст для однієї сторінки, у двох мовних версіях (RU і UA), якщо для мови є семантика.

МЕТОДИКА
1. Інтент і шаблон. За типами сторінок у ТОП-10 (послуги / статті / каталоги / біржі) визнач інтент і обери шаблон:
   - «Лендинг послуги» — у ТОП переважають сторінки послуг;
   - «Гібрид: лендинг послуги + експертний контент» — у ТОП змішано;
   - «Гібрид: експертний лонгрід + послуга» — у ТОП переважають статті, але сторінка комерційна.
   Якщо в ТОП є сторінка самого клієнта (домен проєкту) — це ризик канібалізації, опиши в risks, як розвести інтенти й поставити перелінковку.
2. Обсяг. Орієнтуйся на медіану обсягу основного контенту конкурентів (дано в даних). Текст має бути не коротшим за сильних конкурентів, але без «води». Формат: «8 000–10 000 зн. з пробілами».
3. Структура (blocks). Обов’язкові блоки — ті, що є в більшості сторінок ТОПу. Плюс ПРОГАЛИНИ — корисні блоки, яких немає або які є лише в 1 конкурента (у коментарі познач «у ТОП цього немає»). Порядок: H1 → вступ → визначення/суть → коли потрібно / задачі → що входить → (експертний блок: метрики, порівняльна таблиця, чек-лист, приклад) → CTA → етапи → для кого → ціна → кейси/чому ми → FAQ.
   - Після кожного H1/H2 (і, де треба, після групи H3) — блок type "c": коментар копірайтеру УКРАЇНСЬКОЮ. Він містить обсяг у знаках («600–800 зн.» або «Вступ 150 зн. + кожен H3 200–300 зн.») і конкретно, що написати: тези, приклади, таблиці, які PAA-питання закрити, де вжити ключ.
   - CTA: блок {"type":"cta"}, потім "c" з обсягом, пропозицією (безкоштовний аудит/розрахунок/консультація) і текстом кнопки RU / UA.
   - FAQ: {"type":"faq"}, далі 4–6 {"type":"q"}. Питання беріть із «Люди також питають» і FAQ конкурентів, адаптуй під комерційний інтент.
   - Заголовки H1/H2/H3 пиши обома мовами: ru — природна російська, ua — природна українська (не калька).
4. Ключі. kw_ru / kw_ua — ВСІ ключі з семантики відповідної мови (можна об’єднувати близькі варіанти через « / »), з рекомендованою кількістю входжень на весь текст: «2-3», «1-2», «1 (у визначенні)». Головний ключ — 2–5 разів залежно від обсягу. Ключі з частотою 0–10 — 1 раз. Враховуй, що ключі в заголовках теж рахуються — не став головний ключ у кожен H2.
5. LSI. lsi_ru / lsi_ua — 10–15 тематичних слів/понять, обраних зі списку кандидатів (дано з розрахованими діапазонами, приведеними до цільового обсягу). Пиши читабельно: «утримання клієнтів (варіації)», «Google Карти». Діапазон «мін-макс» бери з даних, округлюй розумно.
6. Факти. НЕ вигадуй ціни, кейси, цифри, гарантії клієнта. Де потрібні дані клієнта — пиши в коментарі «УТОЧНИТИ У КЛІЄНТА». Ринкові орієнтири цін із даних конкурентів можна дати в коментарі як «Орієнтир ринку: …» (без назв компаній у тексті сторінки). Використовуй факти про компанію лише з блоку «Про компанію».
7. top_note — 3–5 речень: обсяги ТОПу (цифрами), що є в усіх, хто найкращий і чим, прогалини, які ми закриваємо. intent — 2–3 речення з доменами ТОПу. title/desc — до ~70 і ~160 знаків, з ключем і брендом.
8. competitors — 4–6 URL сторінок-орієнтирів (без https://).
9. Якщо для мови немає семантики — kw/lsi цієї мови залиш порожніми масивами, а title/desc — порожніми рядками (заголовки в blocks все одно заповни обома мовами).

Поверни результат ТІЛЬКИ через інструмент submit_tz.

ЕТАЛОН ЯКОСТІ (готове ТЗ для іншої сторінки — повтори рівень деталізації, тон і формат коментарів):
""" + json.dumps(EXAMPLE, ensure_ascii=False)

_STR = {"type": "string"}
_KW = {"type": "array", "items": {"type": "object", "properties": {"k": _STR, "f": _STR}, "required": ["k", "f"]}}

TOOL = {
    "name": "submit_tz",
    "description": "Передати готове ТЗ на SEO-текст для сторінки.",
    "input_schema": {
        "type": "object",
        "properties": {
            "short": {"type": "string", "description": "Коротка назва сторінки для назви аркуша (до 20 символів)"},
            "name_ru": _STR,
            "name_ua": _STR,
            "template": {"type": "string", "enum": [
                "Лендинг послуги",
                "Гібрид: лендинг послуги + експертний контент",
                "Гібрид: експертний лонгрід + послуга",
            ]},
            "intent": _STR,
            "url_ru": _STR,
            "url_ua": _STR,
            "volume": _STR,
            "top_note": _STR,
            "title_ru": _STR, "desc_ru": _STR, "title_ua": _STR, "desc_ua": _STR,
            "blocks": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "enum": ["h1", "h2", "h3", "c", "cta", "faq", "q"]},
                        "ru": _STR, "ua": _STR, "text": _STR,
                    },
                    "required": ["type"],
                },
            },
            "kw_ru": _KW, "kw_ua": _KW, "lsi_ru": _KW, "lsi_ua": _KW,
            "competitors": {"type": "array", "items": _STR},
            "risks": _STR,
        },
        "required": ["short", "name_ru", "name_ua", "template", "intent", "volume", "top_note", "blocks",
                     "kw_ru", "kw_ua", "lsi_ru", "lsi_ua", "competitors"],
    },
}


def _comp(p: dict) -> str:
    if p.get("error"):
        return f"- {p['url']} — не вдалося завантажити ({p['error']})"
    hs = "\n".join(f"    {lvl}: {t}" for lvl, t in p["headings"][:45])
    extra = []
    if p.get("faq"):
        extra.append("FAQ: " + " | ".join(p["faq"][:8]))
    if p.get("prices"):
        extra.append("Ціни на сторінці: " + ", ".join(p["prices"][:6]))
    ex = ("\n    " + "\n    ".join(extra)) if extra else ""
    return f"- {p['url']} | {p['type_guess']} | {p['chars']} зн. основного контенту\n{hs}{ex}"


def build_user_prompt(page: dict, project: dict, research: dict) -> str:
    from . import text_types
    parts = []
    tb = text_types.tz_block(text_types.resolve(project))
    if tb:
        parts.append(tb + "\n")
    parts.append("## Про компанію / проєкт")
    parts.append(f"Домен: {project.get('domain') or '—'}")
    parts.append(f"Структура URL: RU — {project.get('url_ru_pattern') or 'корінь сайту'}, UA — {project.get('url_ua_pattern') or '/ua/'}")
    if project.get("facts"):
        parts.append("Факти про компанію (можна використовувати): " + project["facts"])
    if project.get("notes"):
        parts.append("Додаткові вимоги до ТЗ: " + project["notes"])
    if page.get("notes"):
        parts.append("Примітка до цієї сторінки: " + page["notes"])
    for lang in ("ru", "ua"):
        kws = page.get(lang) or []
        if not kws:
            parts.append(f"\n## {lang.upper()}: семантики немає")
            continue
        r = research.get(lang, {})
        parts.append(f"\n## {lang.upper()}-версія. Кластер «{page.get('name_' + lang) or ''}»")
        parts.append("Семантика (ключ — частотність): " + "; ".join(f"{k} — {'?' if v is None else v}" for k, v in kws))
        for s in r.get("serps", []):
            parts.append(f"\n### Видача Google UA за «{s['query']}» (hl={s['lang']})")
            for o in s["organic"]:
                parts.append(f"{o['position']}. {o['url']} — {o['title']}")
            if s.get("paa"):
                parts.append("Люди також питають: " + " | ".join(s["paa"]))
            if s.get("related"):
                parts.append("Пов’язані запити: " + " | ".join(s["related"][:8]))
        if r.get("own_in_serp"):
            parts.append("УВАГА: у видачі є сторінки домену проєкту: " + ", ".join(r["own_in_serp"]))
        parts.append("\n### Розбір сторінок конкурентів (H1–H3, обсяг, FAQ, ціни)")
        parts.extend(_comp(p) for p in r.get("pages", []))
        vs = r.get("volume", {})
        parts.append(f"\nОбсяг основного контенту ТОПу: медіана {vs.get('median')} зн., мін {vs.get('min')}, макс {vs.get('max')}.")
        if r.get("kw_stats"):
            parts.append("Входження ключів у конкурентів (по сторінках): " + "; ".join(
                f"{x['keyword']}: {x['counts']}" for x in r["kw_stats"]))
        if r.get("lsi"):
            parts.append(f"Кандидати LSI (слово | у скількох сторінках | діапазон на цільовий обсяг {r.get('target_chars')} зн.): " + "; ".join(
                f"{x['word']} | {x['docs']} | {x['range']}" for x in r["lsi"]))
    parts.append("\nСклади ТЗ за методикою і передай через submit_tz.")
    return "\n".join(parts)
