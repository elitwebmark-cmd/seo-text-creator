import os
from pathlib import Path


def _env(name: str, default: str = "") -> str:
    """Значення змінної без пробілів і лапок (часта помилка при копіюванні в Railway)."""
    return os.getenv(name, default).strip().strip('"').strip("'").strip()


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = _env("ANTHROPIC_MODEL", "claude-sonnet-4-5")
SERPER_API_KEY = _env("SERPER_API_KEY")
APP_PASSWORD = _env("APP_PASSWORD")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
DATA_DIR = Path(os.getenv("DATA_DIR", "./data")).resolve()
MAX_COMPETITORS = _int("MAX_COMPETITORS", 6)
PARALLEL_CLUSTERS = _int("PARALLEL_CLUSTERS", 2)
MOCK = os.getenv("MOCK", "0") == "1"

DATA_DIR.mkdir(parents=True, exist_ok=True)
(DATA_DIR / "jobs").mkdir(exist_ok=True)

# Домени, які не беремо як конкурентів (довідники, біржі, соцмережі, відео)
SKIP_DOMAINS = {
    "wikipedia.org", "youtube.com", "facebook.com", "instagram.com", "linkedin.com",
    "reddit.com", "olx.ua", "freelancehunt.com", "freelance.ua", "kabanchik.ua",
    "yaprofi.ua", "tiktok.com", "t.me", "twitter.com", "x.com", "google.com",
    "support.google.com", "play.google.com", "apps.apple.com", "gov.ua", "rada.gov.ua",
    "dou.ua", "pinterest.com", "quora.com",
}

DATAFORSEO_LOGIN = _env("DATAFORSEO_LOGIN")
DATAFORSEO_PASSWORD = _env("DATAFORSEO_PASSWORD")
UA_LOCATION_CODE = 2804  # Україна в Google Ads / DataForSEO
# Платні «ідеї ключів» Google Ads при автозборі (за замовчуванням вимкнено — лише частотність)
DATAFORSEO_IDEAS = os.getenv("DATAFORSEO_IDEAS", "0") == "1"
VOLUME_CACHE_DAYS = _int("VOLUME_CACHE_DAYS", 90)

# Перевірка орфографії: LanguageTool (публічний API або власний сервер); порожньо = вимкнено
LANGUAGETOOL_URL = _env("LANGUAGETOOL_URL", "https://api.languagetool.org/v2/check")
TEXT_MAX_FIX_ROUNDS = _int("TEXT_MAX_FIX_ROUNDS", 3)
# Факти з джерелами для текстів: пошук через Serper + перевірка цитат кодом
FACTS_ENABLED = os.getenv("FACTS_ENABLED", "1") == "1"
FACTS_MAX_PAGES = _int("FACTS_MAX_PAGES", 8)
FACTS_MAX_AGE = _int("FACTS_MAX_AGE", 2)
FACTS_EXTRA_DOMAINS = _env("FACTS_EXTRA_DOMAINS")  # додаткові домени-джерела через кому
# ТЗ-аудит тексту (Claude звіряє кожен коментар ТЗ з текстом)
TEXT_AUDIT = os.getenv("TEXT_AUDIT", "1") == "1"
